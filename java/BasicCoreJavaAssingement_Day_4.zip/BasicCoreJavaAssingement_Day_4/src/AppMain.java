
public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//************************* PrintAnimalPattern ****************
				/*System.out.println("********************** PrintAnimalPattern ******************");
				PrintAnimalPattern.pattern();*/
		
		
		//*********************** PrintPatternA*************************
		/*System.out.println("************************* PrintPatternA**********************");
		PrintPatternsA.Pattern();*/
		
		//***************************** PrintPatternB*****************
		/*System.out.println("******************** PrintPatternB **************");
		PrintPatternB.Pattern();*/
		
		//***************************** PrintPatternC*****************
				/*System.out.println("******************** PrintPatternC **************");
				PrintPatternC.pattern();*/
				
				//***************************** PrintPatternD*****************
				/*System.out.println("******************** PrintPatternD **************");
				PrintPatternD.pattern();*/
				
				//***************************** PrintPatternE*****************
				/*System.out.println("******************** PrintPatternE **************");
				PrintPatternE.pattern();
		*/
		//***************************** PrintPatternF ******************
		/*System.out.println("******************** PrintPatternF *******************");
		PrintPatternF.pattern();*/
		
		//***************************** PrintPatternG ******************
				/*System.out.println("******************** PrintPatternG *******************");
				PrintPatternG.pattern();*/
		
		//************************* PrintPatternH ****************
		/*System.out.println("********************** PrintPatternH ******************");
		PrintPatternH.pattern();*/
		
		//************************* PrintPatternI ****************
				/*System.out.println("********************** PrintPatternI ******************");
				PrintPatternI.Pattern();*/
				
				//************************* PrintPatternJ ****************
				/*System.out.println("********************** PrintPatternJ ******************");
				PrintPatternJ.Pattern();*/
				
		
		
				//************************* PrintPatternK ****************
				/*System.out.println("********************** PrintPatternK ******************");
				PrintPatternK.Pattern();
	*/
				
				//************************* PrintPatternL ****************
				/*System.out.println("********************** PrintPatternL ******************");
				PrintPatternL.Pattern();*/
		
		
		//************************* PowerOf2Triangle ****************
		/*System.out.println("********************** PowerOf2Triangle ******************");
		PowerOf2Triangle.pattern();*/
		
		//************************* PascalTriangle2 ****************
				/*System.out.println("********************** PascalTriangle2 ******************");
				PascalTriangle2.pattern();
				*/
				//************************* PascalTriangle1 ****************
				System.out.println("********************** PascalTriangle1 ******************");
				PascalTriangle1.pattern();
				
		
	
	}

}
