import java.util.Scanner;


public class PrintAnimalPattern {
public static void pattern()
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a String");
	String num=s.next();
	int i=0;
	int len=num.length();
	for (i=0;i<len;i++){
		for(int k=0;k<len;k++)
		{
	 System.out.print(num.charAt(i));
	 break;
		}
		for(int j=0;j<len;j++)
		{
			if( (i>0 && i==j) || ( j==len-1-i && i<len-1 )){
				System.out.print("*");
			}
			else
			{
				System.out.print(" ");
			}
		}
		System.out.println("");
	}
	}
	
}

