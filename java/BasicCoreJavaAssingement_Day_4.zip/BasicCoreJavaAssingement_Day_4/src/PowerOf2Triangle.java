import java.util.Scanner;


public class PowerOf2Triangle {

	public static void pattern()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter The Value");
		int num=s.nextInt();
		for(int i=0;i<num;i++)
		{for(int k=num;k>1;k--)
		{
			System.out.print(" ");
		}
			for(int j=i;j<=2*i-1+1;j++)
			{
				System.out.print((int)Math.pow(2, j));
			}
			
			System.out.println(" ");
		}
	}
}
