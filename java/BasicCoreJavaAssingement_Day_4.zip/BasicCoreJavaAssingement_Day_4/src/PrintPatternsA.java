import java.util.Scanner;


public class PrintPatternsA {
public static void Pattern()
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter The Value");
	int num=s.nextInt();
	 for(int i=0;i<=num;i++) {
		  if(i%2==0)
			  System.out.print("0");
		  /*for(int j=1;j<num;j++) {
			System.out.print((i+j)%2+" ");
		  }*/
		  System.out.println("");
	  }
}
}
